package com.sxjs.common.data;

/**
 * Created by admin on 2017/2/22.
 */
public class Constant {
    public static final int TYPE_TOP_BANNER = 0xff01;
    public static final int TYPE_ICON_LIST = 0xff02;
    public static final int TYPE_NEW_USER = 0xff03;
    public static final int TYPE_JD_BULLETIN = 0xff04;
    public static final int TYPE_JD_SPIKE_HEADER = 0xff05;
    public static final int TYPE_JD_SPIKE_CONTENT = 0xff06;
    public static final int TYPE_SHOW_EVENT_3 = 0xff07;
    public static final int TYPE_FIND_GOOD_STUFF = 0xff08;
    public static final int TYPE_WIDTH_PROPORTION_211 = 0xff09;
    public static final int TYPE_TITLE = 0xff10;
    public static final int TYPE_WIDTH_PROPORTION_22 = 0xff11;
    public static final int TYPE_WIDTH_PROPORTION_1111 = 0xff12;
    public static final int TYPE_MIDDLE_BANNER = 0xff13;
    public static final int TYPE_SHOW_EVENT_FILL_UP = 0xff14;
    public static final int TYPE_FIND_GOOD_SHOP = 0xff15;
    public static final int TYPE_PREFERRED_LIST = 0xff16;
    public static final int TYPE_LIVE = 0xff17;
    public static final int TYPE_RECOMMENDED_WARE = 0xff18;

}
