package com.sxjs.common.base.baseadapter.entity;

/**
 * https://github.com/CymChad/BaseRecyclerViewAdapterHelper
 */
public interface MultiItemEntity {

    int getItemType();


}
