package com.sxjs.common.bean;

import java.util.List;

/**
 * Created by Administrator on 2017/7/17.
 */

public class HomeWares  {
    /**
     * code : 200
     * msg : 访问成功
     * isOver : 0
     * timstamp : 1501295885276
     * pageindex : 1
     * items : [{"itemType":"recommended_ware","module":"recommended","itemList":[{"goodsId":292,"catId":369,"goodsSn":"EN1232133600","goodsName":"一加手机3T (A3010) 6GB+64GB 枪灰版 全网通 双卡双待 移动联通电信4G手机","goodsNameStyle":"+","clickCount":999,"brandId":106,"goodsWeight":1,"goodsNumber":1000,"marketPrice":3333.13,"shopPrice":2399,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"商品关键词商品关键词无敌手机","goodsBrief":"商品描述商品描述无敌手机无敌手机无敌手机无敌手机","goodsThumb":"10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg","goodsImg":"10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg","addTime":1496040309000,"isOnSale":1,"salenum":69764,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1500517076000,"goodsType":0,"sellerNote":"商家描述商家描无敌手机","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":291,"catId":63,"goodsSn":"ED23188167","goodsName":"女人志 新款灯笼袖中领毛衣+韩绒料口袋短裙套装送皮带2233","goodsNameStyle":"+","clickCount":13,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":119,"shopPrice":81,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/_thumb_P_1458307388786.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/_P_1458307388302.jpg","addTime":1495073415000,"isOnSale":1,"salenum":23,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1500517076000,"goodsType":2,"sellerNote":"","supplierId":21,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":287,"catId":7,"goodsSn":"ECS000287","goodsName":"韩国原装进口lotte乐天 2%富足水蜜桃果汁饮料240ml听装 夏季饮料","goodsNameStyle":"+","clickCount":15,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":6,"shopPrice":5.3,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/287_thumb_G_1457592139010.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/287_G_1457592139342.jpg","addTime":1495073415000,"isOnSale":1,"salenum":333,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":286,"catId":7,"goodsSn":"ECS000286","goodsName":"永味堂红番石榴汁饮料960ml","goodsNameStyle":"+","clickCount":14,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":16,"shopPrice":13.5,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/286_thumb_G_1457592064813.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/286_G_1457592064658.jpg","addTime":1495073415000,"isOnSale":1,"salenum":454,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":285,"catId":7,"goodsSn":"ECS000285","goodsName":"LOTTE乐天 韩国原装进口 牛奶碳酸饮料 250ml","goodsNameStyle":"+","clickCount":8,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":6,"shopPrice":5.2,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/285_thumb_G_1457590792869.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/285_G_1457590792383.jpg","addTime":1495073415000,"isOnSale":1,"salenum":45,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":284,"catId":0,"goodsSn":"ECS000284","goodsName":"香蕉牛奶 韩国宾格瑞香蕉牛奶饮料200ml12支","goodsNameStyle":"+","clickCount":4,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":70,"shopPrice":59,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/284_thumb_G_1457590275784.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/284_G_1457590275317.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":283,"catId":182,"goodsSn":"ECS000283","goodsName":"好事达家用梯子四步梯加厚梯子折叠梯移动扶梯人字梯2766","goodsNameStyle":"+","clickCount":46,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":2.4,"shopPrice":2,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/_thumb_P_1457590880591.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/_P_1457590880024.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":2,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":282,"catId":218,"goodsSn":"ECS000282","goodsName":"超B级锁芯防伪升级版 防盗门锁芯 防锡纸开门37.5+32.5=70mm","goodsNameStyle":"+","clickCount":3,"brandId":0,"goodsWeight":0,"goodsNumber":997,"marketPrice":154,"shopPrice":129,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/282_thumb_G_1456454106731.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/282_G_1456454106734.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1501292359000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":281,"catId":218,"goodsSn":"ECS000281","goodsName":"卡贝 不锈钢户门吸15CM加长特长墙吸地碰门挡强磁现代家用五金 拉丝不锈钢","goodsNameStyle":"+","clickCount":3,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":46,"shopPrice":39,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/281_thumb_G_1456453972506.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/281_G_1456453972612.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":280,"catId":218,"goodsSn":"ECS000280","goodsName":"宝雕 欧式双舌静音象牙白室内房门锁M87457 象牙白宝雕","goodsNameStyle":"+","clickCount":2,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":118.8,"shopPrice":99,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/280_thumb_G_1456453887329.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/280_G_1456453887069.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null}]}]
     */
    public String code;
    public String msg;
    public String isOver;
    public String timstamp;
    public int pageindex;
    public List<ItemsBean> items;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getIsOver() {
        return isOver;
    }

    public void setIsOver(String isOver) {
        this.isOver = isOver;
    }

    public String getTimstamp() {
        return timstamp;
    }

    public void setTimstamp(String timstamp) {
        this.timstamp = timstamp;
    }

    public int getPageindex() {
        return pageindex;
    }

    public void setPageindex(int pageindex) {
        this.pageindex = pageindex;
    }

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    public static class ItemsBean {
        /**
         * itemType : recommended_ware
         * module : recommended
         * itemList : [{"goodsId":292,"catId":369,"goodsSn":"EN1232133600","goodsName":"一加手机3T (A3010) 6GB+64GB 枪灰版 全网通 双卡双待 移动联通电信4G手机","goodsNameStyle":"+","clickCount":999,"brandId":106,"goodsWeight":1,"goodsNumber":1000,"marketPrice":3333.13,"shopPrice":2399,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"商品关键词商品关键词无敌手机","goodsBrief":"商品描述商品描述无敌手机无敌手机无敌手机无敌手机","goodsThumb":"10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg","goodsImg":"10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg","addTime":1496040309000,"isOnSale":1,"salenum":69764,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1500517076000,"goodsType":0,"sellerNote":"商家描述商家描无敌手机","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":291,"catId":63,"goodsSn":"ED23188167","goodsName":"女人志 新款灯笼袖中领毛衣+韩绒料口袋短裙套装送皮带2233","goodsNameStyle":"+","clickCount":13,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":119,"shopPrice":81,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/_thumb_P_1458307388786.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/_P_1458307388302.jpg","addTime":1495073415000,"isOnSale":1,"salenum":23,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1500517076000,"goodsType":2,"sellerNote":"","supplierId":21,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":287,"catId":7,"goodsSn":"ECS000287","goodsName":"韩国原装进口lotte乐天 2%富足水蜜桃果汁饮料240ml听装 夏季饮料","goodsNameStyle":"+","clickCount":15,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":6,"shopPrice":5.3,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/287_thumb_G_1457592139010.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/287_G_1457592139342.jpg","addTime":1495073415000,"isOnSale":1,"salenum":333,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":286,"catId":7,"goodsSn":"ECS000286","goodsName":"永味堂红番石榴汁饮料960ml","goodsNameStyle":"+","clickCount":14,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":16,"shopPrice":13.5,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/286_thumb_G_1457592064813.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/286_G_1457592064658.jpg","addTime":1495073415000,"isOnSale":1,"salenum":454,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":285,"catId":7,"goodsSn":"ECS000285","goodsName":"LOTTE乐天 韩国原装进口 牛奶碳酸饮料 250ml","goodsNameStyle":"+","clickCount":8,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":6,"shopPrice":5.2,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/285_thumb_G_1457590792869.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/285_G_1457590792383.jpg","addTime":1495073415000,"isOnSale":1,"salenum":45,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":284,"catId":0,"goodsSn":"ECS000284","goodsName":"香蕉牛奶 韩国宾格瑞香蕉牛奶饮料200ml12支","goodsNameStyle":"+","clickCount":4,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":70,"shopPrice":59,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/284_thumb_G_1457590275784.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/284_G_1457590275317.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":1,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":18,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":283,"catId":182,"goodsSn":"ECS000283","goodsName":"好事达家用梯子四步梯加厚梯子折叠梯移动扶梯人字梯2766","goodsNameStyle":"+","clickCount":46,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":2.4,"shopPrice":2,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201603/thumb_img/_thumb_P_1457590880591.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201603/goods_img/_P_1457590880024.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":2,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":282,"catId":218,"goodsSn":"ECS000282","goodsName":"超B级锁芯防伪升级版 防盗门锁芯 防锡纸开门37.5+32.5=70mm","goodsNameStyle":"+","clickCount":3,"brandId":0,"goodsWeight":0,"goodsNumber":997,"marketPrice":154,"shopPrice":129,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/282_thumb_G_1456454106731.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/282_G_1456454106734.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1501292359000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":281,"catId":218,"goodsSn":"ECS000281","goodsName":"卡贝 不锈钢户门吸15CM加长特长墙吸地碰门挡强磁现代家用五金 拉丝不锈钢","goodsNameStyle":"+","clickCount":3,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":46,"shopPrice":39,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/281_thumb_G_1456453972506.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/281_G_1456453972612.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null},{"goodsId":280,"catId":218,"goodsSn":"ECS000280","goodsName":"宝雕 欧式双舌静音象牙白室内房门锁M87457 象牙白宝雕","goodsNameStyle":"+","clickCount":2,"brandId":0,"goodsWeight":0,"goodsNumber":1000,"marketPrice":118.8,"shopPrice":99,"promotePrice":99,"promoteStartDate":1500451889000,"promoteEndDate":1500624696000,"keywords":"","goodsBrief":"","goodsThumb":"10.10.140.231:81/shop/data/images/201602/thumb_img/280_thumb_G_1456453887329.jpg","goodsImg":"10.10.140.231:81/shop/data/images/201602/goods_img/280_G_1456453887069.jpg","addTime":1495073415000,"isOnSale":1,"salenum":0,"sortOrder":100,"isDelete":0,"isBest":0,"isNew":1,"isHot":1,"isPromote":1,"isDiscount":0,"returnMoney":2,"lastUpdate":1495073422000,"goodsType":0,"sellerNote":"","supplierId":0,"supplierStatus":1,"specialGoods":0,"reuseOne":null,"reuseTwo":null,"reuseThree":null}]
         */

        public String itemType;
        public String module;
        public List<ItemListBean> itemList;

        public String getItemType() {
            return itemType;
        }

        public void setItemType(String itemType) {
            this.itemType = itemType;
        }

        public String getModule() {
            return module;
        }

        public void setModule(String module) {
            this.module = module;
        }

        public List<ItemListBean> getItemList() {
            return itemList;
        }

        public void setItemList(List<ItemListBean> itemList) {
            this.itemList = itemList;
        }

        public static class ItemListBean {
            /**
             * goodsId : 292
             * catId : 369
             * goodsSn : EN1232133600
             * goodsName : 一加手机3T (A3010) 6GB+64GB 枪灰版 全网通 双卡双待 移动联通电信4G手机
             * goodsNameStyle : +
             * clickCount : 999
             * brandId : 106
             * goodsWeight : 1
             * goodsNumber : 1000
             * marketPrice : 3333.13
             * shopPrice : 2399
             * promotePrice : 99
             * promoteStartDate : 1500451889000
             * promoteEndDate : 1500624696000
             * keywords : 商品关键词商品关键词无敌手机
             * goodsBrief : 商品描述商品描述无敌手机无敌手机无敌手机无敌手机
             * goodsThumb : 10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg
             * goodsImg : 10.10.140.231:81/shop/data/images/20170529/58343dc1Nbb3d4722.jpg
             * addTime : 1496040309000
             * isOnSale : 1
             * salenum : 69764
             * sortOrder : 100
             * isDelete : 0
             * isBest : 1
             * isNew : 1
             * isHot : 1
             * isPromote : 1
             * isDiscount : 0
             * returnMoney : 2
             * lastUpdate : 1500517076000
             * goodsType : 0
             * sellerNote : 商家描述商家描无敌手机
             * supplierId : 0
             * supplierStatus : 1
             * specialGoods : 0
             * reuseOne : null
             * reuseTwo : null
             * reuseThree : null
             */

            public int goodsId;
            public int catId;
            public String goodsSn;
            public String goodsName;
            public String goodsNameStyle;
            public int clickCount;
            public int brandId;
            public int goodsWeight;
            public int goodsNumber;
            public String marketPrice;
            public String shopPrice;
            public String promotePrice;
            public String promoteStartDate;
            public String promoteEndDate;
            public String keywords;
            public String goodsBrief;
            public String goodsThumb;
            public String goodsImg;
            public long addTime;
            public int isOnSale;
            public int salenum;
            public int sortOrder;
            public int isDelete;
            public int isBest;
            public int isNew;
            public int isHot;
            public int isPromote;
            public int isDiscount;
            public int returnMoney;
            public long lastUpdate;
            public int goodsType;
            public String sellerNote;
            public int supplierId;
            public int supplierStatus;
            public int specialGoods;
            public String reuseOne;
            public String reuseTwo;
            public String reuseThree;
            /**
             * adId : 90
             * positionId : 65
             * mediaType : 0
             * adName : 首页幻灯片1
             * adLink :
             * startTime : 1496062234000
             * endTime : 1496062238000
             * linkMan :
             * linkEmail :
             * linkPhone :
             * enabled : 1
             * adCode : 10.10.140.231:81/shop/data/images/afficheimg/20150722uzphik.jpg
             */

            public int adId;
            public int positionId;
            public int mediaType;
            public String adName;
            public String adLink;
            public long startTime;
            public long endTime;
            public String linkMan;
            public String linkEmail;
            public String linkPhone;
            public int enabled;
            public String adCode;

            public int getAdId() {
                return adId;
            }

            public void setAdId(int adId) {
                this.adId = adId;
            }

            public int getPositionId() {
                return positionId;
            }

            public void setPositionId(int positionId) {
                this.positionId = positionId;
            }

            public int getMediaType() {
                return mediaType;
            }

            public void setMediaType(int mediaType) {
                this.mediaType = mediaType;
            }

            public String getAdName() {
                return adName;
            }

            public void setAdName(String adName) {
                this.adName = adName;
            }

            public String getAdLink() {
                return adLink;
            }

            public void setAdLink(String adLink) {
                this.adLink = adLink;
            }

            public long getStartTime() {
                return startTime;
            }

            public void setStartTime(long startTime) {
                this.startTime = startTime;
            }

            public long getEndTime() {
                return endTime;
            }

            public void setEndTime(long endTime) {
                this.endTime = endTime;
            }

            public String getLinkMan() {
                return linkMan;
            }

            public void setLinkMan(String linkMan) {
                this.linkMan = linkMan;
            }

            public String getLinkEmail() {
                return linkEmail;
            }

            public void setLinkEmail(String linkEmail) {
                this.linkEmail = linkEmail;
            }

            public String getLinkPhone() {
                return linkPhone;
            }

            public void setLinkPhone(String linkPhone) {
                this.linkPhone = linkPhone;
            }

            public int getEnabled() {
                return enabled;
            }

            public void setEnabled(int enabled) {
                this.enabled = enabled;
            }

            public String getAdCode() {
                return adCode;
            }

            public void setAdCode(String adCode) {
                this.adCode = adCode;
            }

            public int getGoodsId() {
                return goodsId;
            }

            public void setGoodsId(int goodsId) {
                this.goodsId = goodsId;
            }

            public int getCatId() {
                return catId;
            }

            public void setCatId(int catId) {
                this.catId = catId;
            }

            public String getGoodsSn() {
                return goodsSn;
            }

            public void setGoodsSn(String goodsSn) {
                this.goodsSn = goodsSn;
            }

            public String getGoodsName() {
                return goodsName;
            }

            public void setGoodsName(String goodsName) {
                this.goodsName = goodsName;
            }

            public String getGoodsNameStyle() {
                return goodsNameStyle;
            }

            public void setGoodsNameStyle(String goodsNameStyle) {
                this.goodsNameStyle = goodsNameStyle;
            }

            public int getClickCount() {
                return clickCount;
            }

            public void setClickCount(int clickCount) {
                this.clickCount = clickCount;
            }

            public int getBrandId() {
                return brandId;
            }

            public void setBrandId(int brandId) {
                this.brandId = brandId;
            }

            public int getGoodsWeight() {
                return goodsWeight;
            }

            public void setGoodsWeight(int goodsWeight) {
                this.goodsWeight = goodsWeight;
            }

            public int getGoodsNumber() {
                return goodsNumber;
            }

            public void setGoodsNumber(int goodsNumber) {
                this.goodsNumber = goodsNumber;
            }

            public String getMarketPrice() {
                return marketPrice;
            }

            public void setMarketPrice(String marketPrice) {
                this.marketPrice = marketPrice;
            }

            public String getShopPrice() {
                return shopPrice;
            }

            public void setShopPrice(String shopPrice) {
                this.shopPrice = shopPrice;
            }

            public String getPromotePrice() {
                return promotePrice;
            }

            public void setPromotePrice(String promotePrice) {
                this.promotePrice = promotePrice;
            }

            public String getPromoteStartDate() {
                return promoteStartDate;
            }

            public void setPromoteStartDate(String promoteStartDate) {
                this.promoteStartDate = promoteStartDate;
            }

            public String getPromoteEndDate() {
                return promoteEndDate;
            }

            public void setPromoteEndDate(String promoteEndDate) {
                this.promoteEndDate = promoteEndDate;
            }

            public String getKeywords() {
                return keywords;
            }

            public void setKeywords(String keywords) {
                this.keywords = keywords;
            }

            public String getGoodsBrief() {
                return goodsBrief;
            }

            public void setGoodsBrief(String goodsBrief) {
                this.goodsBrief = goodsBrief;
            }

            public String getGoodsThumb() {
                return goodsThumb;
            }

            public void setGoodsThumb(String goodsThumb) {
                this.goodsThumb = goodsThumb;
            }

            public String getGoodsImg() {
                return goodsImg;
            }

            public void setGoodsImg(String goodsImg) {
                this.goodsImg = goodsImg;
            }

            public long getAddTime() {
                return addTime;
            }

            public void setAddTime(long addTime) {
                this.addTime = addTime;
            }

            public int getIsOnSale() {
                return isOnSale;
            }

            public void setIsOnSale(int isOnSale) {
                this.isOnSale = isOnSale;
            }

            public int getSalenum() {
                return salenum;
            }

            public void setSalenum(int salenum) {
                this.salenum = salenum;
            }

            public int getSortOrder() {
                return sortOrder;
            }

            public void setSortOrder(int sortOrder) {
                this.sortOrder = sortOrder;
            }

            public int getIsDelete() {
                return isDelete;
            }

            public void setIsDelete(int isDelete) {
                this.isDelete = isDelete;
            }

            public int getIsBest() {
                return isBest;
            }

            public void setIsBest(int isBest) {
                this.isBest = isBest;
            }

            public int getIsNew() {
                return isNew;
            }

            public void setIsNew(int isNew) {
                this.isNew = isNew;
            }

            public int getIsHot() {
                return isHot;
            }

            public void setIsHot(int isHot) {
                this.isHot = isHot;
            }

            public int getIsPromote() {
                return isPromote;
            }

            public void setIsPromote(int isPromote) {
                this.isPromote = isPromote;
            }

            public int getIsDiscount() {
                return isDiscount;
            }

            public void setIsDiscount(int isDiscount) {
                this.isDiscount = isDiscount;
            }

            public int getReturnMoney() {
                return returnMoney;
            }

            public void setReturnMoney(int returnMoney) {
                this.returnMoney = returnMoney;
            }

            public long getLastUpdate() {
                return lastUpdate;
            }

            public void setLastUpdate(long lastUpdate) {
                this.lastUpdate = lastUpdate;
            }

            public int getGoodsType() {
                return goodsType;
            }

            public void setGoodsType(int goodsType) {
                this.goodsType = goodsType;
            }

            public String getSellerNote() {
                return sellerNote;
            }

            public void setSellerNote(String sellerNote) {
                this.sellerNote = sellerNote;
            }

            public int getSupplierId() {
                return supplierId;
            }

            public void setSupplierId(int supplierId) {
                this.supplierId = supplierId;
            }

            public int getSupplierStatus() {
                return supplierStatus;
            }

            public void setSupplierStatus(int supplierStatus) {
                this.supplierStatus = supplierStatus;
            }

            public int getSpecialGoods() {
                return specialGoods;
            }

            public void setSpecialGoods(int specialGoods) {
                this.specialGoods = specialGoods;
            }

            public String getReuseOne() {
                return reuseOne;
            }

            public void setReuseOne(String reuseOne) {
                this.reuseOne = reuseOne;
            }

            public String getReuseTwo() {
                return reuseTwo;
            }

            public void setReuseTwo(String reuseTwo) {
                this.reuseTwo = reuseTwo;
            }

            public String getReuseThree() {
                return reuseThree;
            }

            public void setReuseThree(String reuseThree) {
                this.reuseThree = reuseThree;
            }
        }
    }

}
