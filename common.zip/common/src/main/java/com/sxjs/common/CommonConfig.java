package com.sxjs.common;

/**
 * Created by admin on 2017/3/9.
 */

public class CommonConfig {
    public static int HTTP_READ_TIME_OUT = 15;
    public static int HTTP_CONNECT_TIME_OUT = 15;
    public static String SUCCESS_CODE="200";
    public static String BASE_URL = "http://10.10.140.231:8080/XJD/api/";
    public static boolean DEBUG = true;
    public static String SHARE_PREFERENCE_FILE_NAME = "diantudaikuan";
    public static boolean LOGIN = true;
}
